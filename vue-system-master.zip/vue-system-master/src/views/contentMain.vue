<template>
    <div class="contentMain">
        This is a Homepage.
        <input >
    </div>
</template>

<script>
    export default {
        name: "contentMain"
    }
</script>

<style scoped>
  .contentMain{
      height: 100%;
  }

</style>
