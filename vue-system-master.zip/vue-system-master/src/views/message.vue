<template>
  <div class="abc">
    This is a message.
  </div>
</template>

<script>
  export default {
    name: "abc"
  }
</script>

<style scoped>
  .abc{
    height: 100%;
  }

</style>
